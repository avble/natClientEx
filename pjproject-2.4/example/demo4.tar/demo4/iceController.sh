#!/bin/sh 
./iceController -s stun.l.google.com:19302 -S  115.77.49.188  -P 12345 -U huy2 

