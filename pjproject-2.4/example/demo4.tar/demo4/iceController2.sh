#!/bin/sh 
./iceController -s stun.l.google.com:19302 -S  115.77.49.188  -P 12345 -U user2 -t 115.77.49.188:3478 -u 100  -p 100 
